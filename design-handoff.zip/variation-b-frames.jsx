// variation-b-frames.jsx — Mobile + Desktop frame compositions for variation B

function BHeaderGreen({ size = 'mobile' }) {
  const isDesk = size === 'desktop';
  return (
    <div style={{
      background: 'var(--brand)',
      color: '#fff',
      padding: isDesk ? '22px 24px 26px' : '18px 18px 22px',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* Decorative orbs */}
      <div style={{ position:'absolute', top:-40, right:-30, width:160, height:160, borderRadius:'50%', background:'rgba(255,255,255,.08)' }} />
      <div style={{ position:'absolute', bottom:-50, left:-20, width:120, height:120, borderRadius:'50%', background:'rgba(255,255,255,.05)' }} />

      <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:10, position:'relative' }}>
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', opacity: .8 }}>Cita · #{APPT.id.slice(-3)}</div>
          <div style={{ fontSize: isDesk ? 28 : 22, fontWeight: 800, lineHeight: 1.05, marginTop: 4, letterSpacing:'-.01em' }}>
            {APPT.timeStart} – {APPT.timeEnd}
          </div>
          <div style={{ fontSize: 13, opacity: .92, marginTop: 4, fontWeight: 500 }}>
            {APPT.weekday}, {APPT.date} · {APPT.duration} min
          </div>
        </div>
        <button style={{
          width: 34, height: 34, borderRadius: 10, border: 'none',
          background: 'rgba(255,255,255,.18)', color: '#fff', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
          backdropFilter: 'blur(8px)',
        }}><Icon.Close /></button>
      </div>

      <div style={{ marginTop: 18, position: 'relative' }}>
        <BTimeline current={1} theme="on-green" />
      </div>
    </div>
  );
}

// ─── B · Mobile ────────────────────────────────────────────────────────────
function BMobile() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0f1715', overflow: 'hidden' }}>
      <div style={{ position:'absolute', inset:0, background:'linear-gradient(180deg, #1d2825, #0f1715)', opacity:0.55 }} />
      <div style={{ position:'absolute', inset:0, opacity:.15, background:`
        repeating-linear-gradient(0deg, rgba(255,255,255,.06) 0 1px, transparent 1px 60px),
        repeating-linear-gradient(90deg, rgba(255,255,255,.06) 0 1px, transparent 1px 56px)
      `}}/>

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, top: 28,
        background: 'var(--paper-2)',
        borderRadius: '22px 22px 0 0',
        boxShadow: '0 -16px 50px rgba(0,0,0,.28)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* Grabber */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '6px 0 0', background: 'var(--teal-700)' }}>
          <div style={{ width: 36, height: 4, borderRadius: 999, background: 'rgba(255,255,255,.5)' }} />
        </div>

        <BHeaderGreen size="mobile" />

        <div style={{
          flex: 1, overflow: 'auto',
          padding: '16px 16px 16px',
          display: 'flex', flexDirection: 'column', gap: 'var(--gap-card, 16px)',
        }}>
          <BClientCard />
          <BProChip />

          <div>
            <div style={{ fontSize: 'var(--fs-label,11.5px)', fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--ink-400)', marginBottom: 8 }}>Servicios</div>
            <BServices />
          </div>

          <BTotalCard />
          <BCompleteZone />

          {/* Subtle bottom row */}
          <div style={{ display: 'flex', gap: 8, marginTop: 4 }}>
            <button style={{
              flex: 1, height: 40, borderRadius: 10, border: '1px solid var(--line)',
              background: 'var(--paper)', color: 'var(--ink-700)',
              fontSize: 13, fontWeight: 600, cursor: 'pointer',
              display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
            }}><Icon.Calendar /> Reagendar</button>
            <button style={{
              height: 40, borderRadius: 10, border: '1px solid var(--line)',
              background: 'var(--paper)', color: 'var(--rose)',
              fontSize: 13, fontWeight: 600, cursor: 'pointer', padding: '0 14px',
              display: 'inline-flex', alignItems: 'center', gap: 6,
            }}>
              <Icon.X /> Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── B · Desktop ───────────────────────────────────────────────────────────
function BDesktop() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#f7f7f4', overflow: 'hidden' }}>
      <ACalendarBackdrop />
      <div style={{ position:'absolute', inset:0, background:'rgba(15,23,21,.32)' }} />

      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 500,
        background: 'var(--paper-2)',
        boxShadow: '-24px 0 60px rgba(0,0,0,.18)',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <BHeaderGreen size="desktop" />

        <div style={{
          flex: 1, overflow: 'auto', padding: '18px 22px 18px',
          display: 'flex', flexDirection: 'column', gap: 'var(--gap-card, 16px)',
        }}>
          <BClientCard />

          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12 }}>
            <BProChip />
            <BTotalCard />
          </div>

          <div>
            <div style={{ fontSize: 'var(--fs-label,11.5px)', fontWeight: 700, letterSpacing: '.08em', textTransform: 'uppercase', color: 'var(--ink-400)', marginBottom: 8 }}>Servicios</div>
            <BServices />
          </div>

          <BCompleteZone />
        </div>

        <div style={{
          padding: '12px 22px',
          borderTop: '1px solid var(--line)', background: 'var(--paper)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <button style={{ flex:1, height: 40, borderRadius: 10, border: '1px solid var(--line)', background: 'var(--paper)', color: 'var(--ink-700)', fontWeight: 600, fontSize: 13, cursor: 'pointer', display:'inline-flex', alignItems:'center', justifyContent:'center', gap:6 }}><Icon.Calendar /> Reagendar</button>
          <button style={{ height: 40, borderRadius: 10, border: '1px solid var(--rose-soft)', background: 'var(--rose-soft)', color: 'var(--rose)', fontWeight: 600, fontSize: 13, cursor: 'pointer', padding: '0 14px', display:'inline-flex', alignItems:'center', gap:6 }}><Icon.X /> Cancelar cita</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { BMobile, BDesktop });
