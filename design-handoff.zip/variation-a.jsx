// variation-a.jsx — Conservadora pulida, alineada al estilo del perfil de negocio
// Lenguaje visual extraído de la pantalla de referencia:
//   • Barra teal sólida arriba (#008080), contenido en una "hoja" blanca debajo
//   • Cards blancas con borde 1px var(--line), radio ~14px
//   • Tarjeta destacada: borde + fondo teal-50 (estilo "Más cercana")
//   • Stats en columnas con números grandes en teal
//   • Section labels: 11.5px, 700, uppercase, letter-spacing .08em, ink-400
//   • CTA principal: full-width, fondo --brand, radio 14px, peso 700

// ─── Sección labels y bloques compartidos ─────────────────────────────────
function ASectionLabel({ children, hint, right }) {
  return (
    <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 10 }}>
      <div style={{
        fontSize: 'var(--fs-label, 11.5px)', fontWeight: 700,
        letterSpacing: '0.08em', textTransform: 'uppercase',
        color: 'var(--ink-400)',
      }}>
        {children}{hint && <span style={{color:'var(--ink-300)',fontWeight:600,marginLeft:6}}>· {hint}</span>}
      </div>
      {right}
    </div>
  );
}

// Status pill en teal (en vez del azul actual), para alinear con el lenguaje de la app
function AStatusPill({ status }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '4px 10px', borderRadius: 999,
      background: 'var(--teal-50)', color: 'var(--brand)',
      fontWeight: 600, fontSize: 12, letterSpacing: '.01em',
      border: '1px solid var(--teal-100)',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: 'var(--brand)' }} />
      Confirmada
    </span>
  );
}

// ─── Card cliente (con tel + WhatsApp inline) ─────────────────────────────
function AClientCard({ compact }) {
  return (
    <div style={{
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--radius-card, 14px)',
      padding: 'var(--pad-card, 16px)',
      display: 'flex', alignItems: 'center', gap: 14,
    }}>
      <Avatar initials={APPT.client.initials} size={48} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, color: 'var(--ink-900)', fontSize: 15.5, lineHeight: 1.2 }}>{APPT.client.name}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-500)', marginTop: 2, display: 'flex', alignItems: 'center', gap: 6, fontVariantNumeric:'tabular-nums' }}>
          <Icon.Phone style={{ width: 12, height: 12, color: 'var(--ink-400)' }} />
          {APPT.client.phone}
        </div>
      </div>
      <div style={{ display: 'flex', gap: 6, flexShrink: 0 }}>
        <button title="Llamar" style={{
          width: 36, height: 36, borderRadius: 10, border: '1px solid var(--line)',
          background: 'var(--paper)', color: 'var(--brand)', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon.Phone /></button>
        <button title="WhatsApp" style={{
          width: 36, height: 36, borderRadius: 10, border: 'none',
          background: '#25d366', color: '#fff', cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}><Icon.Whatsapp /></button>
      </div>
    </div>
  );
}

function AProCard() {
  return (
    <div style={{
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--radius-card, 14px)',
      padding: 'var(--pad-card, 16px)',
      display: 'flex', alignItems: 'center', gap: 14,
    }}>
      <Avatar initials={APPT.pro.initials} size={48} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 700, color: 'var(--ink-900)', fontSize: 15.5, lineHeight: 1.2 }}>{APPT.pro.name}</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-500)', marginTop: 2 }}>{APPT.pro.role}</div>
      </div>
    </div>
  );
}

// ─── Stats row (estilo "4.7 · Puntuación") ────────────────────────────────
function AStatsRow() {
  const Stat = ({ value, label }) => (
    <div style={{
      flex: 1,
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--radius-card, 14px)',
      padding: '14px 12px',
      textAlign: 'center',
    }}>
      <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--brand)', lineHeight: 1, letterSpacing: '-.01em' }}>{value}</div>
      <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 6 }}>{label}</div>
    </div>
  );
  return (
    <div style={{ display: 'flex', gap: 10 }}>
      <Stat value={APPT.duration + ' min'} label="Duración" />
      <Stat value={'#' + APPT.services.length} label="Servicio" />
      <Stat value={APPT.client.visits} label="Visita del cliente" />
    </div>
  );
}

// ─── Servicios + total (look limpio en tabla) ─────────────────────────────
function AServiceList() {
  return (
    <div style={{
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 'var(--radius-card, 14px)',
      overflow: 'hidden',
    }}>
      {APPT.services.map((s, i) => (
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 12,
          padding: 'var(--pad-card, 14px) var(--pad-card, 16px)',
        }}>
          <div style={{
            width: 36, height: 36, borderRadius: 10, background: 'var(--teal-50)',
            display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)',
            flexShrink: 0,
          }}><Icon.Sparkle /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 600, color: 'var(--ink-900)', fontSize: 14.5 }}>{s.name}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-400)' }}>{s.minutes} min · 1 unidad</div>
          </div>
          <span style={{ fontVariantNumeric: 'tabular-nums', color: 'var(--ink-900)', fontWeight: 700, fontSize: 14.5 }}>{money(s.price)}</span>
        </div>
      ))}
    </div>
  );
}

function ATotalRow() {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '14px 4px',
    }}>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--ink-400)' }}>Total a cobrar</div>
        <div style={{ fontSize: 12, color: 'var(--ink-400)', marginTop: 2 }}>Subtotal {money(APPT.subtotal)}</div>
      </div>
      <div style={{ fontSize: 26, fontWeight: 800, color: 'var(--brand)', letterSpacing: '-.01em', fontVariantNumeric: 'tabular-nums' }}>
        {money(APPT.total)}
      </div>
    </div>
  );
}

// ─── Bloque destacado "Completar la cita" (estilo "Más cercana") ──────────
function ACompleteHighlight() {
  return (
    <div style={{
      background: 'var(--teal-50)',
      border: '1px solid var(--brand)',
      borderRadius: 'var(--radius-card, 14px)',
      padding: 'var(--pad-card, 16px)',
      display: 'flex', flexDirection: 'column', gap: 12,
    }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
        <div style={{
          width: 36, height: 36, borderRadius: 10, background: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--brand)',
          flexShrink: 0, border: '1px solid var(--teal-100)',
        }}><Icon.Camera /></div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 14.5, fontWeight: 700, color: 'var(--ink-900)' }}>Sube la foto del resultado</div>
          <div style={{ fontSize: 12.5, color: 'var(--ink-500)', marginTop: 2 }}>
            Adjunta una imagen para marcar la cita como completada.
          </div>
        </div>
      </div>

      <label style={{
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        height: 88, borderRadius: 12, cursor: 'pointer',
        border: '1.5px dashed var(--teal-300)',
        background: '#fff',
        color: 'var(--brand)', fontSize: 13, fontWeight: 600,
      }}>
        <Icon.Upload style={{ width: 18, height: 18 }} />
        Arrastra o toca para subir
      </label>
    </div>
  );
}

// ─── Header teal sólido (móvil y desktop) ─────────────────────────────────
function AHeaderTeal({ onClose, size = 'mobile' }) {
  const isDesk = size === 'desktop';
  return (
    <div style={{
      background: 'var(--brand)', color: '#fff',
      padding: isDesk ? '22px 24px 18px' : '18px 18px 16px',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10,
    }}>
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', opacity: .82 }}>
          Cita · #{APPT.id.slice(-3)}
        </div>
        <div style={{ fontSize: isDesk ? 24 : 20, fontWeight: 800, lineHeight: 1.15, marginTop: 4, letterSpacing: '-.01em' }}>
          {APPT.client.name}
        </div>
        <div style={{ fontSize: 13, opacity: .92, marginTop: 4, display: 'flex', flexWrap: 'wrap', gap: 12 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icon.Calendar /> {APPT.weekday} {APPT.date}
          </span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
            <Icon.Clock /> {APPT.timeStart} – {APPT.timeEnd}
          </span>
        </div>
      </div>
      <button onClick={onClose} style={{
        width: 34, height: 34, borderRadius: 10, border: 'none',
        background: 'rgba(255,255,255,.18)', color: '#fff', cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
      }}><Icon.Close /></button>
    </div>
  );
}

// Status strip just under header (white bg)
function AStatusStrip() {
  return (
    <div style={{
      padding: '12px 18px',
      background: 'var(--paper)',
      borderBottom: '1px solid var(--line)',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    }}>
      <AStatusPill />
      <span style={{ fontSize: 12.5, color: 'var(--ink-500)', fontWeight: 500 }}>
        Pago pendiente
      </span>
    </div>
  );
}

// ─── A · Mobile (bottom sheet) ────────────────────────────────────────────
function AMobile() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#0f1715', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #1d2825, #0f1715)', opacity: 0.55 }} />
      <div style={{ position:'absolute', inset:0, opacity:.15, background: `
        repeating-linear-gradient(0deg, rgba(255,255,255,.06) 0 1px, transparent 1px 60px),
        repeating-linear-gradient(90deg, rgba(255,255,255,.06) 0 1px, transparent 1px 56px)
      `}} />

      <div style={{
        position: 'absolute', left: 0, right: 0, bottom: 0, top: 32,
        background: 'var(--paper-2)',
        borderRadius: '22px 22px 0 0',
        boxShadow: '0 -16px 50px rgba(0,0,0,.28)',
        display: 'flex', flexDirection: 'column',
        overflow: 'hidden',
      }}>
        {/* Grabber sits on teal header */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '6px 0 0', background: 'var(--brand)' }}>
          <div style={{ width: 36, height: 4, borderRadius: 999, background: 'rgba(255,255,255,.5)' }} />
        </div>

        <AHeaderTeal size="mobile" />
        <AStatusStrip />

        <div style={{
          flex: 1, overflow: 'auto',
          padding: '16px 16px 16px',
          display: 'flex', flexDirection: 'column', gap: 'var(--gap-card, 16px)',
        }}>
          <section>
            <ASectionLabel>Cliente</ASectionLabel>
            <AClientCard />
          </section>

          <section>
            <ASectionLabel>Profesional</ASectionLabel>
            <AProCard />
          </section>

          <AStatsRow />

          <section>
            <ASectionLabel hint={`${APPT.services.length} servicio`}>Servicios</ASectionLabel>
            <AServiceList />
            <ATotalRow />
          </section>

          <ACompleteHighlight />

          {/* Primary action — full-width solid teal */}
          <button style={{
            width: '100%', height: 52, borderRadius: 14, border: 'none',
            background: 'var(--brand)', color: '#fff',
            fontSize: 15.5, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          }}>
            <Icon.Check /> Marcar como completada
          </button>

          {/* Secondary ghost row */}
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={ghostBtn}><Icon.Plus /> Agregar servicio</button>
            <button style={ghostBtn}><Icon.Calendar /> Reagendar</button>
          </div>

          <button style={{
            height: 40, borderRadius: 10, border: 'none', background: 'transparent',
            color: 'var(--rose)', fontSize: 13.5, fontWeight: 600, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            <Icon.X /> Cancelar cita
          </button>
        </div>
      </div>
    </div>
  );
}

const ghostBtn = {
  flex: 1, height: 42, borderRadius: 12,
  border: '1px solid var(--line)',
  background: 'var(--paper)', color: 'var(--ink-700)',
  fontSize: 13, fontWeight: 600, cursor: 'pointer',
  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
};

// ─── A · Desktop (right drawer over calendar) ─────────────────────────────
function ADesktop() {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: '#f7f7f4', overflow: 'hidden' }}>
      <ACalendarBackdrop />
      <div style={{ position:'absolute', inset:0, background:'rgba(15,23,21,.32)' }} />

      <div style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 480,
        background: 'var(--paper-2)',
        boxShadow: '-24px 0 60px rgba(0,0,0,.18)',
        display: 'flex', flexDirection: 'column', overflow: 'hidden',
      }}>
        <AHeaderTeal size="desktop" />
        <AStatusStrip />

        <div style={{
          flex: 1, overflow: 'auto',
          padding: '18px 22px 18px',
          display: 'flex', flexDirection: 'column', gap: 'var(--gap-card, 16px)',
        }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <section>
              <ASectionLabel>Cliente</ASectionLabel>
              <AClientCard />
            </section>
            <section>
              <ASectionLabel>Profesional</ASectionLabel>
              <AProCard />
            </section>
          </div>

          <AStatsRow />

          <section>
            <ASectionLabel hint={`${APPT.services.length} servicio`}>Servicios</ASectionLabel>
            <AServiceList />
            <ATotalRow />
          </section>

          <ACompleteHighlight />
        </div>

        {/* Footer: primary CTA + ghost row */}
        <div style={{
          padding: '14px 22px',
          background: 'var(--paper)',
          borderTop: '1px solid var(--line)',
          display: 'flex', flexDirection: 'column', gap: 10,
        }}>
          <button style={{
            width: '100%', height: 48, borderRadius: 14, border: 'none',
            background: 'var(--brand)', color: '#fff',
            fontSize: 15, fontWeight: 700, cursor: 'pointer',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
          }}>
            <Icon.Check /> Marcar como completada
          </button>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={ghostBtn}><Icon.Plus /> Agregar servicio</button>
            <button style={ghostBtn}><Icon.Calendar /> Reagendar</button>
            <button style={{ ...ghostBtn, flex: '0 0 auto', padding: '0 16px', color: 'var(--rose)', background: 'var(--rose-soft)', border: '1px solid var(--rose-soft)' }}>
              <Icon.X /> Cancelar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Calendar backdrop (unchanged) ────────────────────────────────────────
function ACalendarBackdrop() {
  const days = ['LUN 11','MAR 12','MIE 13','JUE 14','VIE 15','SAB 16','DOM 17'];
  return (
    <div style={{ position:'absolute', inset:0, padding: '0 0 0 220px', display:'flex', flexDirection:'column' }}>
      <div style={{ position:'absolute', left:0, top:0, bottom:0, width:220, background:'#fff', borderRight:'1px solid var(--line)', padding: '18px 16px' }}>
        <div style={{ fontFamily:'Plus Jakarta Sans', fontWeight:800, fontSize:20, color:'var(--brand)' }}>Siliba</div>
        <div style={{ marginTop: 22, display:'flex', flexDirection:'column', gap:4 }}>
          {['Inicio','Punto de Venta','Reportes','Citas','Clientes','Servicios','Personal','Inventario','Tienda','Notificaciones','Configuración'].map((it, i) => (
            <div key={i} style={{
              padding:'8px 10px', borderRadius:8, fontSize:13.5,
              fontWeight: i===3?600:500,
              color: i===3?'var(--brand)':'var(--ink-700)',
              background: i===3?'var(--teal-50)':'transparent',
            }}>{it}</div>
          ))}
        </div>
      </div>
      <div style={{ height: 56, borderBottom:'1px solid var(--line)', background:'#fff', display:'flex', alignItems:'center', padding:'0 24px', justifyContent:'space-between' }}>
        <div style={{ fontSize:18, fontWeight:700, color:'var(--ink-900)' }}>Citas</div>
        <button style={{ height: 36, padding: '0 14px', borderRadius: 8, background:'var(--brand)', color:'#fff', border:'none', fontWeight:600, fontSize:13.5 }}>Nuevo</button>
      </div>
      <div style={{ flex:1, display:'grid', gridTemplateColumns:`60px repeat(7, 1fr)`, gridTemplateRows:'auto 1fr', background:'#fff' }}>
        <div></div>
        {days.map((d,i) => (
          <div key={i} style={{ padding:'10px 8px', borderBottom:'1px solid var(--line)', borderLeft:'1px solid var(--line-2)', fontSize:11, fontWeight:600, color: i===3?'var(--brand)':'var(--ink-500)', letterSpacing:'.05em' }}>{d}</div>
        ))}
        <div style={{ display:'flex', flexDirection:'column', borderRight:'1px solid var(--line-2)' }}>
          {['10','11','12','13'].map(h => (
            <div key={h} style={{ flex:1, padding:'6px 8px', fontSize:11, color:'var(--ink-400)', borderBottom:'1px solid var(--line-2)' }}>{h}:00</div>
          ))}
        </div>
        {[...Array(7)].map((_, col) => (
          <div key={col} style={{ borderLeft:'1px solid var(--line-2)', position:'relative' }}>
            {col === 3 && (
              <div style={{ position:'absolute', left:6, right:6, top:'30%', height:'40%', background:'var(--teal-100)', borderLeft:'3px solid var(--brand)', borderRadius:6, padding:'6px 8px' }}>
                <div style={{ fontSize:11, fontWeight:700, color:'var(--teal-800)' }}>11:00 — Fernando</div>
                <div style={{ fontSize:10, color:'var(--teal-700)' }}>Tinte de Cabello</div>
              </div>
            )}
            {col === 1 && (<div style={{ position:'absolute', left:6, right:6, top:'15%', height:'25%', background:'var(--teal-100)', borderLeft:'3px solid var(--brand)', borderRadius:6 }}/>)}
            {col === 4 && (<div style={{ position:'absolute', left:6, right:6, top:'50%', height:'20%', background:'#ede9fe', borderLeft:'3px solid #8b5cf6', borderRadius:6 }}/>)}
            {col === 5 && (<div style={{ position:'absolute', left:6, right:6, top:'35%', height:'35%', background:'#fef3c7', borderLeft:'3px solid var(--amber)', borderRadius:6 }}/>)}
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { AMobile, ADesktop });
