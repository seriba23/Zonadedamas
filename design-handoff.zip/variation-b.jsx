// variation-b.jsx — Atrevida, más visual + verde de marca
// Architecture:
//   • Green hero header with timeline (Agendada → Confirmada → En curso → Completada)
//   • Big client card with hero photo + tel/WhatsApp as primary actions
//   • Services as visual chips with prices
//   • Total in bold green totals card
//   • Drop zone HUGE — primary visual + action of the screen
//   • Secondary actions reduced to icon-buttons

// ── Timeline ───────────────────────────────────────────────────────────────
function BTimeline({ current = 1, theme = 'light' }) {
  const steps = ['Agendada', 'Confirmada', 'En curso', 'Completada'];
  const trackBg = theme === 'on-green' ? 'rgba(255,255,255,.25)' : 'var(--line)';
  const doneFg  = theme === 'on-green' ? '#fff' : 'var(--teal-600)';
  const todoFg  = theme === 'on-green' ? 'rgba(255,255,255,.55)' : 'var(--ink-400)';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, width: '100%' }}>
      {steps.map((s, i) => (
        <React.Fragment key={s}>
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, flexShrink: 0 }}>
            <div style={{
              width: 22, height: 22, borderRadius: 999,
              background: i <= current ? doneFg : trackBg,
              color: i <= current ? (theme === 'on-green' ? 'var(--teal-700)' : '#fff') : 'transparent',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 11, fontWeight: 800,
              boxShadow: i === current ? '0 0 0 4px ' + (theme === 'on-green' ? 'rgba(255,255,255,.18)' : 'var(--teal-100)') : 'none',
            }}>
              {i < current ? <Icon.Check style={{width:12,height:12}} /> : i === current ? '●' : ''}
            </div>
            <div style={{ fontSize: 10.5, fontWeight: 600, color: i <= current ? doneFg : todoFg, whiteSpace: 'nowrap' }}>{s}</div>
          </div>
          {i < steps.length - 1 && (
            <div style={{ flex: 1, height: 2, background: i < current ? doneFg : trackBg, borderRadius: 999, marginTop: -14 }} />
          )}
        </React.Fragment>
      ))}
    </div>
  );
}

// ── Client mega-card ───────────────────────────────────────────────────────
function BClientCard() {
  return (
    <div style={{
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 16,
      padding: 'var(--pad-card, 16px)',
      display: 'flex', flexDirection: 'column', gap: 14,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Avatar initials={APPT.client.initials} size={52} />
        <div style={{ minWidth: 0, flex: 1 }}>
          <div style={{ fontSize: 11.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--ink-400)' }}>Cliente</div>
          <div style={{ fontWeight: 700, color: 'var(--ink-900)', fontSize: 17, lineHeight: 1.15, marginTop: 1 }}>{APPT.client.name}</div>
          <div style={{ fontSize: 12.5, color: 'var(--ink-500)', marginTop: 2 }}>
            {APPT.client.visits} visitas · última {APPT.client.lastVisit}
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button style={{
          flex: 1, height: 44, borderRadius: 12, border: '1px solid var(--line)',
          background: 'var(--paper-2)', color: 'var(--ink-900)',
          fontWeight: 600, fontSize: 13.5, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        }}>
          <Icon.Phone /> Llamar
        </button>
        <button style={{
          flex: 1, height: 44, borderRadius: 12, border: 'none',
          background: '#25d366', color: '#fff',
          fontWeight: 700, fontSize: 13.5, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
          boxShadow: '0 4px 12px -4px rgba(37,211,102,.6)',
        }}>
          <Icon.Whatsapp /> WhatsApp
        </button>
      </div>
    </div>
  );
}

// ── Pro chip (compact) ─────────────────────────────────────────────────────
function BProChip() {
  return (
    <div style={{
      background: 'var(--paper)',
      border: '1px solid var(--line)',
      borderRadius: 16,
      padding: 14,
      display: 'flex', alignItems: 'center', gap: 12,
    }}>
      <Avatar initials={APPT.pro.initials} size={40} />
      <div style={{ minWidth: 0, flex: 1 }}>
        <div style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--ink-400)' }}>Profesional</div>
        <div style={{ fontWeight: 700, color: 'var(--ink-900)', fontSize: 14.5 }}>{APPT.pro.name}</div>
        <div style={{ fontSize: 11.5, color: 'var(--ink-500)' }}>{APPT.pro.role}</div>
      </div>
    </div>
  );
}

// ── Services as visual cards ───────────────────────────────────────────────
function BServices() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      {APPT.services.map((s, i) => (
        <div key={i} style={{
          background: 'var(--paper)', border: '1px solid var(--line)', borderRadius: 14,
          padding: 14,
          display: 'flex', alignItems: 'center', gap: 12,
        }}>
          {/* tiny swatch */}
          <div style={{
            width: 40, height: 40, borderRadius: 10,
            background: 'var(--teal-50)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: 'var(--brand)', flexShrink: 0,
          }}><Icon.Sparkle /></div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontWeight: 700, color: 'var(--ink-900)', fontSize: 14.5 }}>{s.name}</div>
            <div style={{ fontSize: 12, color: 'var(--ink-400)' }}>{s.minutes} min</div>
          </div>
          <div style={{ fontWeight: 700, fontSize: 15, color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums' }}>{money(s.price)}</div>
        </div>
      ))}

      {/* Add service tile */}
      <button style={{
        height: 44, borderRadius: 12, border: '1.5px dashed var(--line)',
        background: 'transparent', color: 'var(--ink-500)',
        fontWeight: 600, fontSize: 13, cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      }}>
        <Icon.Plus /> Agregar otro servicio
      </button>
    </div>
  );
}

// ── Total card ─────────────────────────────────────────────────────────────
function BTotalCard() {
  return (
    <div style={{
      background: 'var(--brand)',
      borderRadius: 16, padding: 'var(--pad-card, 18px)',
      color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
    }}>
      <div>
        <div style={{ fontSize: 11.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', opacity: .8 }}>Total a cobrar</div>
        <div style={{ fontSize: 12, opacity: .85, marginTop: 2 }}>{APPT.duration} min · 1 servicio</div>
      </div>
      <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-.01em', fontVariantNumeric: 'tabular-nums' }}>
        {money(APPT.total)}
      </div>
    </div>
  );
}

// ── Big drop zone ──────────────────────────────────────────────────────────
function BCompleteZone() {
  return (
    <div style={{
      borderRadius: 18, overflow: 'hidden',
      border: '1px solid var(--teal-200)',
      background: 'var(--paper)',
    }}>
      <div style={{ padding: '14px 16px 0' }}>
        <div style={{ fontSize: 11.5, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', color: 'var(--brand)' }}>
          Paso final
        </div>
        <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--ink-900)', marginTop: 2 }}>Sube el resultado y completa</div>
        <div style={{ fontSize: 12.5, color: 'var(--ink-500)', marginTop: 2 }}>
          La foto se publica en el portfolio de {APPT.pro.name.split(' ')[0]}.
        </div>
      </div>

      <label style={{
        margin: '12px 16px 0',
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
        height: 140, borderRadius: 14, cursor: 'pointer',
        border: '1.5px dashed var(--teal-300)',
        background: 'var(--teal-50)',
        color: 'var(--brand)',
      }}>
        <Icon.Camera style={{ width: 28, height: 28, color: 'var(--brand)' }} />
        <div style={{ fontSize: 14, fontWeight: 700 }}>Arrastra fotos aquí</div>
        <div style={{ fontSize: 11.5, color: 'var(--brand)', opacity: .75 }}>o toca para elegir desde tu dispositivo</div>
      </label>

      <div style={{ padding: 16, paddingTop: 12 }}>
        <button style={{
          width: '100%', height: 52, borderRadius: 14, border: 'none',
          background: 'var(--brand)', color: '#fff',
          fontSize: 15.5, fontWeight: 700, cursor: 'pointer',
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        }}>
          <Icon.Check /> Marcar como completada
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { BTimeline, BClientCard, BProChip, BServices, BTotalCard, BCompleteZone });
